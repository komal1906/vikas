package com.capgemini.capstore.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.dao.IReturnDao;


@Controller
public class ReturnGoodsController {

/*	
	@Autowired
	private  IReturnDao returndao;*/

	 
	
/*	@RequestMapping(value = "/", method = RequestMethod.POST)
	public Double applyCoupon(String couponCode, Double price)  {

		return repo.applyCoupons(couponCode, price);

	}
	
*/	
	 
} 