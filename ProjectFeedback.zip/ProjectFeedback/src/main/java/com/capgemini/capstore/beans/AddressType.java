package com.capgemini.capstore.beans;

public enum AddressType 
{
	HOME,WORK
}
