package com.capgemini.capstore.dao;

public interface IReturnDao {
	public boolean refundMoney(int orderId);
}