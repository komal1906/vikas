package com.capgemini.capstore.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.capgemini.capstore.beans.Feedback;
import com.capgemini.capstore.services.FeedbackService;


@Controller
public class FeedbackController {

	@Autowired
	FeedbackService fser;
	
	@RequestMapping(value="/")
	public String createFeedback()  {
		return "FeedbackRating";
	}
	
	@RequestMapping(value="/success")
	public String addfeed(@ModelAttribute("feed") Feedback fee) {
		System.out.println(fser.addfeedback(fee));
		return "sucess";
	}
	
}
