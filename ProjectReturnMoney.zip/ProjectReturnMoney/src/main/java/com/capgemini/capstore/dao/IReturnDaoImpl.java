package com.capgemini.capstore.dao;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Orders;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.service.IReturnService;


@Transactional
@Repository("repo")
public class IReturnDaoImpl implements IReturnDao{

	@PersistenceContext
	EntityManager entityManager;


 public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean refundMoney(int order_id) {
		
		/*
		Product prod=new Product();
		Orders order=new Orders();
		Query prod1= entityManager.createQuery("Select o.prod_id from orders_product o where o.order_id=:oid").setParameter("oid", order_id);
		Object pidf=prod1.getSingleResult();
		
          String or1=order.getOrderStatus();
          if(or1.equals("returned"))
          {
        	  if(order.getPaymentOptions().equals("NETBANKING")) {
           	  prod.getPrice();
           	  
        	  }
        	  
          }
          double price=prod.getPrice();
          orders.getOrder_id();
           String payment=order.getPaymentOptions();
       */
		Orders o1= new Orders();
		String ostatus=o1.getOrderStatus();
		if(ostatus.equals("RETURNED"))
		{
			Query prod1= entityManager.createQuery("Select o.prod_id from orders_product o where o.order_id=:oid").setParameter("oid", order_id);
			Object pidf=prod1.getSingleResult();
		
		}
		
		
		
		return false;
	}

}
