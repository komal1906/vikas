package com.capgemini.capstore.repo;

import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Feedback;

@Repository("frepo")
public class FeedbackRepoImpl implements FeedbackRepo{

	@PersistenceContext
	EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Override
	public String addfeedback(Feedback fee) {
		
		Random ran=new Random();
		String fid="F#"+Integer.toString(ran.nextInt(10));
		fee.setFeedback_id(fid);
		entityManager.persist(fee);
		entityManager.flush();
		return fid;
	}

}
