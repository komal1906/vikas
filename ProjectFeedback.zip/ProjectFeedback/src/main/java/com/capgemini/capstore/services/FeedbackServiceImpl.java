package com.capgemini.capstore.services;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.capstore.beans.Feedback;
import com.capgemini.capstore.repo.FeedbackRepo;

@Transactional
@Service("fservice")
public class FeedbackServiceImpl implements FeedbackService {
	
	@Autowired
	FeedbackRepo frepo;
	public String addfeedback(Feedback fee)
	{
		return frepo.addfeedback(fee);
		
	}
}
