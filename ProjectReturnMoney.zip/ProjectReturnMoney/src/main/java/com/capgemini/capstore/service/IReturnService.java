package com.capgemini.capstore.service;

public interface IReturnService {
	public boolean refundMoney(int orderId);
		

}
