package com.capgemini.capstore.beans;

public enum PaymentMethods 
{
	CASH_ON_DELIVERY , NETBANKING , CARD;
}
